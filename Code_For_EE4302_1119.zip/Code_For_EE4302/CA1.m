% CA1:
% 4.0 state space modelling of the orginal system:
% 4.0.1. system modelling:
A = [0,     1   ;
    -1.20, -3.71];
B = [0;
     1];
C = [1, 0];
CFullState = [1, 0;
     0, 1];
D = 0;
sys = ss(A, B, C, D);
sysFullState = ss(A, B, CFullState, D);
% 4.0.1. model parameters:
[wn, zeta, poles] = damp(sys);
disp(wn)
% 4.0.2. check for controllability:
controllabilityMat = [B, A*B];
disp(controllabilityMat) % full rank: controllable

% 4.1 use Ackermann's Formula to do the feedback control: u = -K*X
% 4.1.1. Choose closed loop ploes using ITAE: A is 2 by 2, so 2 poles:
polesAim = [-0.7071-1.068i;
            -0.7071+1.068i];
% 4.1.2. use Ackermann's Formula to get gain K:
K = acker(A,B,polesAim);
% 4.1.3. form the controlled system:
feedbackControl = ss(0,[0,0],0,K);
sysWithFeedbackControl = feedback(sysFullState, feedbackControl, -1);
[wn1, zeta1, poles1] = damp(sysWithFeedbackControl);
disp(poles1) % poles < 0, stable poles
figure(1)
bode(sysWithFeedbackControl)
figure(2)
step(sysWithFeedbackControl)


